import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { createAppointment, getAppointments, updateAppointmentStatus } from "./db";
import { z } from "zod";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  appointments: router({
    create: publicProcedure
      .input(z.object({
        name: z.string(),
        email: z.string().email(),
        phone: z.string(),
        clientCPF: z.string(),
        services: z.string(),
        totalPrice: z.string(),
        appointmentDate: z.string(),
        appointmentTime: z.string(),
        referralCPF: z.string().optional(),
        message: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await createAppointment({
          name: input.name,
          email: input.email,
          phone: input.phone,
          clientCPF: input.clientCPF,
          services: input.services,
          totalPrice: input.totalPrice as any,
          appointmentDate: input.appointmentDate,
          appointmentTime: input.appointmentTime,
          referralCPF: input.referralCPF || null,
          message: input.message || null,
          status: 'pendente',
        });
      }),
    
    list: protectedProcedure
      .query(async ({ ctx }) => {
        if (ctx.user?.role !== 'admin') {
          throw new Error('Unauthorized');
        }
        return await getAppointments();
      }),
    
    updateStatus: protectedProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(['pendente', 'confirmado', 'concluido', 'cancelado']),
      }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user?.role !== 'admin') {
          throw new Error('Unauthorized');
        }
        return await updateAppointmentStatus(input.id, input.status);
      }),
  }),
});

export type AppRouter = typeof appRouter;
