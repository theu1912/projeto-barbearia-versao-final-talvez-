'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { MessageCircle, Instagram, Star, MapPin, Phone, Clock, X } from 'lucide-react';
import { MapView } from '@/components/Map';
import { trpc } from '@/lib/trpc';

/**
 * DESIGN PHILOSOPHY: Luxury Barbershop Conversion Engine
 * - Borgonha (#800020) + Dourado (#D4AF37) para identidade premium
 * - Serviços interativos com seleção visual
 * - Validação CPF anti-fraude com lógica matemática
 * - Integração Make.com para automação
 * - Sistema de Fidelidade: Rastreio de indicações e desconto de 10%
 */

// ⚠️ CONFIGURE AQUI: Cole a URL do seu Webhook do Make.com
const M_WEBHOOK_URL = 'https://hook.make.com/YOUR_WEBHOOK_URL_HERE';

interface Service {
  id: string;
  name: string;
  price: number;
  selected: boolean;
}

interface FormData {
  name: string;
  email: string;
  phone: string;
  service: string;
  date: string;
  time: string;
  professional: string;
  clientCPF: string;
  referralCPF: string;
  message: string;
}

interface FidelityData {
  clientCPF: string;
  referralCount: number;
  discountPercentage: number;
  lastReferralDate: string;
}

// Validação de CPF com lógica matemática
const validateCPF = (cpf: string): boolean => {
  // Remove caracteres não-numéricos
  const cleanCPF = cpf.replace(/\D/g, '');

  // Verifica se tem 11 dígitos
  if (cleanCPF.length !== 11) return false;

  // Verifica se todos os dígitos são iguais (CPF inválido)
  if (/^(\d)\1{10}$/.test(cleanCPF)) return false;

  // Calcula primeiro dígito verificador
  let sum = 0;
  let remainder;
  for (let i = 1; i <= 9; i++) {
    sum += parseInt(cleanCPF.substring(i - 1, i)) * (11 - i);
  }
  remainder = (sum * 10) % 11;
  if (remainder === 10 || remainder === 11) remainder = 0;
  if (remainder !== parseInt(cleanCPF.substring(9, 10))) return false;

  // Calcula segundo dígito verificador
  sum = 0;
  for (let i = 1; i <= 10; i++) {
    sum += parseInt(cleanCPF.substring(i - 1, i)) * (12 - i);
  }
  remainder = (sum * 10) % 11;
  if (remainder === 10 || remainder === 11) remainder = 0;
  if (remainder !== parseInt(cleanCPF.substring(10, 11))) return false;

  return true;
};

// Máscara de CPF
const maskCPF = (value: string): string => {
  const cleanValue = value.replace(/\D/g, '');
  return cleanValue
    .replace(/(\d{3})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d{1,2})$/, '$1-$2')
    .substring(0, 14);
};

// Máscara de Telefone
const maskPhone = (value: string): string => {
  const cleanValue = value.replace(/\D/g, '');
  return cleanValue
    .replace(/(\d{2})(\d)/, '($1) $2')
    .replace(/(\d{4})(\d)/, '$1-$2')
    .substring(0, 15);
};

export default function Home() {
  const [services, setServices] = useState<Service[]>([
    { id: '1', name: 'Corte Tradicional', price: 60, selected: false },
    { id: '2', name: 'Barba Terapia', price: 50, selected: false },
    { id: '3', name: 'Combo (Corte + Barba)', price: 100, selected: false },
    { id: '4', name: 'Sobrancelha', price: 20, selected: false },
    { id: '5', name: 'Pezinho', price: 15, selected: false },
  ]);

  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [formData, setFormData] = useState<FormData>({
    name: '',
    email: '',
    phone: '',
    service: '',
    date: '',
    time: '',
    professional: '',
    clientCPF: '',
    referralCPF: '',
    message: '',
  });

  const [cpfError, setCpfError] = useState('');
  const [referralCpfError, setReferralCpfError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  // Calcula total de serviços selecionados
  const selectedServices = services.filter(s => s.selected);
  const totalPrice = selectedServices.reduce((sum, s) => sum + s.price, 0);
  const selectedServicesText = selectedServices.map(s => s.name).join(', ');

  // Toggle seleção de serviço
  const toggleService = (id: string) => {
    setServices(services.map(s =>
      s.id === id ? { ...s, selected: !s.selected } : s
    ));
  };

  // Abre modal com serviços preenchidos
  const openScheduleModal = () => {
    setFormData(prev => ({
      ...prev,
      service: selectedServicesText || '',
    }));
    setShowScheduleModal(true);
  };

  // Valida CPF do cliente
  const handleClientCPFChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const masked = maskCPF(e.target.value);
    setFormData(prev => ({ ...prev, clientCPF: masked }));

    if (masked.length === 14) {
      if (!validateCPF(masked)) {
        setCpfError('CPF inválido. Verifique os dígitos.');
      } else {
        setCpfError('');
      }
    }
  };

  // Valida CPF de indicação
  const handleReferralCPFChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const masked = maskCPF(e.target.value);
    setFormData(prev => ({ ...prev, referralCPF: masked }));

    if (masked.length === 14) {
      if (!validateCPF(masked)) {
        setReferralCpfError('CPF de indicação inválido.');
      } else if (maskCPF(formData.clientCPF) === masked) {
        setReferralCpfError('O CPF de indicação não pode ser igual ao seu CPF.');
      } else {
        setReferralCpfError('');
      }
    }
  };

  // Sanitiza dados para envio ao Webhook
  const sanitizeData = (data: FormData) => {
    const cleanClientCPF = data.clientCPF.replace(/\D/g, '');
    const cleanReferralCPF = data.referralCPF.replace(/\D/g, '');
    
    // Sistema de Fidelidade: Calcula desconto baseado em indicacoes
    const fidelityData: FidelityData = {
      clientCPF: cleanClientCPF,
      referralCount: cleanReferralCPF ? 1 : 0,
      discountPercentage: cleanReferralCPF ? 10 : 0,
      lastReferralDate: new Date().toISOString(),
    };
    
    return {
      name: data.name.trim(),
      email: data.email.trim(),
      phone: data.phone.replace(/\D/g, ''),
      services: selectedServicesText,
      totalPrice,
      date: data.date,
      time: data.time,
      clientCPF: cleanClientCPF,
      referralCPF: cleanReferralCPF,
      message: data.message.trim(),
      fidelity: fidelityData,
      timestamp: new Date().toISOString(),
    };
  };

  // Mutation para criar agendamento
  const createAppointmentMutation = trpc.appointments.create.useMutation({
    onSuccess: () => {
      setSuccessMessage('Agendamento realizado com sucesso! Você receberá uma confirmação em breve.');
      setFormData({
        name: '',
        email: '',
        phone: '',
        service: '',
        date: '',
        time: '',
        clientCPF: '',
        referralCPF: '',
        message: '',
      });
      setTimeout(() => {
        setShowScheduleModal(false);
        setSuccessMessage('');
      }, 3000);
    },
    onError: (error) => {
      alert('Erro ao criar agendamento. Tente novamente.');
      console.error('Erro:', error);
    },
  });

  // Envia para banco de dados e Make.com Webhook
  const handleScheduleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validações
    if (!formData.name || !formData.email || !formData.phone || !formData.date || !formData.time) {
      alert('Por favor, preencha todos os campos obrigatórios.');
      return;
    }

    if (cpfError || !validateCPF(formData.clientCPF)) {
      alert('CPF inválido. Por favor, verifique.');
      return;
    }

    if (totalPrice > 0 && formData.referralCPF) {
      if (referralCpfError || !validateCPF(formData.referralCPF)) {
        alert('CPF de indicação inválido.');
        return;
      }
    }

    try {
      const sanitizedData = sanitizeData(formData);

      // Cria agendamento no banco de dados
      await createAppointmentMutation.mutateAsync({
        name: sanitizedData.name,
        email: sanitizedData.email,
        phone: sanitizedData.phone,
        clientCPF: sanitizedData.clientCPF,
        services: sanitizedData.services,
        totalPrice: sanitizedData.totalPrice.toString(),
        appointmentDate: sanitizedData.date,
        appointmentTime: sanitizedData.time,
        referralCPF: sanitizedData.referralCPF || undefined,
        message: sanitizedData.message || undefined,
      });

      // Envia para Make.com Webhook (opcional)
      try {
        await fetch(M_WEBHOOK_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(sanitizedData),
        });
      } catch (webhookError) {
        console.warn('Webhook não enviado, mas agendamento foi salvo:', webhookError);
      }
    } catch (error) {
      console.error('Erro:', error);
      alert('Erro ao conectar ao servidor. Tente novamente.');
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-white/95 backdrop-blur-sm z-50 border-b border-[#D4AF37]/20 shadow-sm">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-[#800020] rounded-full flex items-center justify-center">
              <span className="text-white font-bold text-sm">✂</span>
            </div>
            <span className="font-bold text-[#800020] text-lg">Von Barbarov</span>
          </div>
          <div className="hidden md:flex items-center gap-8">
            <a href="#historia" className="text-gray-700 hover:text-[#800020] transition-colors font-medium">HISTÓRIA</a>
            <a href="#servicos" className="text-gray-700 hover:text-[#800020] transition-colors font-medium">SERVIÇOS</a>
            <a href="#depoimentos" className="text-gray-700 hover:text-[#800020] transition-colors font-medium">DEPOIMENTOS</a>
            <a href="#localizacao" className="text-gray-700 hover:text-[#800020] transition-colors font-medium">LOCALIZAÇÃO</a>
            <a href="#contato" className="text-gray-700 hover:text-[#800020] transition-colors font-medium">CONTATO</a>
          </div>
          <Button
            onClick={openScheduleModal}
            className="bg-[#800020] hover:bg-[#600018] text-white font-bold"
          >
            AGENDAR
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 md:pb-32 bg-gradient-to-b from-gray-50 to-white relative overflow-hidden">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <p className="text-[#D4AF37] font-semibold text-sm tracking-widest">DESDE 2015</p>
                <h1 className="text-5xl md:text-6xl lg:text-7xl font-serif font-bold text-[#800020] leading-tight">
                  Unindo o Clássico e o Moderno
                </h1>
              </div>
              <p className="text-lg text-gray-600 leading-relaxed max-w-lg">
                Cuidando da sua história desde 2015. A Von Barbarov é referência em barbearia premium, combinando tradição, excelência e profissionalismo.
              </p>
              <div className="flex gap-4 pt-4">
                <Button
                  onClick={openScheduleModal}
                  className="bg-[#D4AF37] hover:bg-[#C49A27] text-[#800020] font-bold px-8 py-6 text-lg"
                >
                  AGENDAR AGORA
                </Button>
                <Button
                  variant="outline"
                  className="border-2 border-[#800020] text-[#800020] hover:bg-[#800020] hover:text-white font-bold px-8 py-6 text-lg"
                >
                  CONHEÇA-NOS
                </Button>
              </div>
            </div>
            <div className="relative h-96 md:h-full rounded-lg overflow-hidden shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1599351431202-924373718914?w=600&h=600&fit=crop"
                alt="Barbeiro profissional"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#800020]/30 to-transparent"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Serviços Interativos Section */}
      <section id="servicos" className="py-20 md:py-32 bg-white">
        <div className="container">
          <div className="space-y-4 mb-12">
            <p className="text-[#D4AF37] font-semibold text-sm tracking-widest">NOSSOS SERVIÇOS</p>
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-[#800020]">
              Excelência em Cada Detalhe
            </h2>
          </div>

          {/* Service Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
            {services.map(service => (
              <div
                key={service.id}
                onClick={() => toggleService(service.id)}
                className={`p-6 rounded-lg cursor-pointer transition-all duration-300 border-2 ${
                  service.selected
                    ? 'bg-[#800020] text-white border-[#800020]'
                    : 'bg-white text-gray-800 border-gray-200 hover:border-[#D4AF37]'
                } ${
                  service.name === 'Combo (Corte + Barba)' && !service.selected
                    ? 'border-[#D4AF37] border-4'
                    : ''
                }`}
              >
                <div className="space-y-3">
                  <h3 className="font-bold text-lg">{service.name}</h3>
                  <p className={`text-2xl font-bold ${service.selected ? 'text-[#D4AF37]' : 'text-[#800020]'}`}>
                    R$ {service.price}
                  </p>
                  <div className={`text-sm font-semibold ${service.selected ? 'text-white' : 'text-[#D4AF37]'}`}>
                    {service.selected ? '✓ SELECIONADO' : 'Selecionar'}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Resumo de Seleção */}
          <div className="bg-gradient-to-r from-[#800020]/10 to-[#D4AF37]/10 p-6 rounded-lg border-l-4 border-[#D4AF37]">
            <p className="text-gray-800 font-semibold">
              Serviços selecionados: <span className="text-[#800020]">{selectedServices.length}</span> | 
              Total: <span className="text-[#800020] text-xl font-bold"> R$ {totalPrice.toFixed(2)}</span>
            </p>
          </div>
        </div>
      </section>

      {/* História Section */}
      <section id="historia" className="py-20 md:py-32 bg-gray-50">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-2">
                <p className="text-[#D4AF37] font-semibold text-sm tracking-widest">NOSSA HISTÓRIA</p>
                <h2 className="text-4xl md:text-5xl font-serif font-bold text-[#800020]">
                  Um Negócio com Propósito
                </h2>
              </div>
              <p className="text-gray-700 leading-relaxed text-lg">
                Sonhe Grande, Comece Pequeno, Mas Comece Agora! Foi com base nisso que a Barbearia Von Barbarov surgiu, após muito estudo, dedicação e 1 ano cortando na cozinha da nossa casa.
              </p>
              <p className="text-gray-700 leading-relaxed text-lg">
                Hoje somos referência no mercado de barbearia premium, destacando-nos principalmente pelo nosso propósito de trazer o homem a sua verdadeira essência. Cada cliente sai muito melhor do que entrou.
              </p>
              <div className="flex gap-8 pt-4">
                <div className="space-y-2">
                  <p className="text-[#D4AF37] font-bold text-2xl">10+</p>
                  <p className="text-gray-600 font-semibold">Anos de Experiência</p>
                </div>
                <div className="space-y-2">
                  <p className="text-[#D4AF37] font-bold text-2xl">5000+</p>
                  <p className="text-gray-600 font-semibold">Clientes Satisfeitos</p>
                </div>
              </div>
            </div>
            <div className="relative h-96 rounded-lg overflow-hidden shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1585747860715-cd4628902d4a?w=600&h=600&fit=crop"
                alt="Interior da barbearia"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Depoimentos Section */}
      <section id="depoimentos" className="py-20 md:py-32 bg-white">
        <div className="container">
          <div className="space-y-4 mb-12">
            <p className="text-[#D4AF37] font-semibold text-sm tracking-widest">NOSSOS CLIENTES</p>
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-[#800020]">
              O que Dizem Sobre Nós
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: 'Carlos Silva',
                role: 'Cliente desde 2018',
                text: 'Melhor barbearia de Curitiba! Os barbeiros são muito profissionais e o ambiente é impecável.',
                rating: 5,
              },
              {
                name: 'João Pereira',
                role: 'Cliente frequente',
                text: 'Sempre saio satisfeito com o resultado. Recomendo para todos os meus amigos!',
                rating: 5,
              },
              {
                name: 'Pedro Costa',
                role: 'Cliente desde 2019',
                text: 'Atendimento excelente, profissionais qualificados e um ambiente acolhedor. Voltarei sempre!',
                rating: 5,
              },
            ].map((testimonial, idx) => (
              <div key={idx} className="bg-gray-50 p-8 rounded-lg border-l-4 border-[#D4AF37] hover:shadow-lg transition-shadow">
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-[#D4AF37] text-[#D4AF37]" />
                  ))}
                </div>
                <p className="text-gray-700 mb-4 italic">"{testimonial.text}"</p>
                <p className="font-bold text-[#800020]">{testimonial.name}</p>
                <p className="text-sm text-gray-600">{testimonial.role}</p>
              </div>
            ))}
          </div>

          {/* Google Reviews Widget */}
          <div className="mt-12 bg-white p-8 rounded-lg shadow-md border-t-4 border-[#D4AF37]">
            <div className="flex items-center gap-3 mb-6">
              <div className="flex gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-[#D4AF37] text-[#D4AF37]" />
                ))}
              </div>
              <p className="text-lg font-bold text-[#800020]">4.9 de 5 (807 avaliações)</p>
            </div>
            <p className="text-gray-600 mb-4">Confira nossas avaliações no Google Maps e veja por que somos referência em barbearia premium em Curitiba.</p>
            <a
              href="https://www.google.com/maps/place/Barbearia+Von+Barbarov+Boqueir%C3%A3o/@-25.508612,-49.2496814,17z"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-[#800020] hover:bg-[#600018] text-white font-bold py-3 px-6 rounded-lg transition-all duration-300 hover:shadow-lg"
            >
              Ver no Google Maps
            </a>
          </div>
        </div>
      </section>

      {/* Localização Section */}
      <section id="localizacao" className="py-20 md:py-32 bg-gray-50">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-start">
            <div className="space-y-8">
              <div className="space-y-2">
                <p className="text-[#D4AF37] font-semibold text-sm tracking-widest">ONDE ESTAMOS</p>
                <h2 className="text-4xl md:text-5xl font-serif font-bold text-[#800020]">
                  Visite Nossa Unidade
                </h2>
              </div>

              <div className="bg-white p-8 rounded-lg shadow-md border-l-4 border-[#D4AF37] space-y-6">
                <div className="flex gap-4">
                  <MapPin className="w-6 h-6 text-[#D4AF37] flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-bold text-[#800020] mb-1">Boqueirão</h3>
                    <p className="text-gray-600 text-sm md:text-base">R. Waldemar Loureiro Campos, 2885</p>
                    <p className="text-gray-600 text-sm md:text-base">Curitiba, PR</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Phone className="w-6 h-6 text-[#D4AF37] flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-bold text-[#800020] mb-1">Telefone</h3>
                    <a href="tel:+554132057764" className="text-[#D4AF37] hover:text-[#D4AF37]/80 text-sm md:text-base font-semibold">
                      (41) 3205-7764
                    </a>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Clock className="w-6 h-6 text-[#D4AF37] flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-bold text-[#800020] mb-1">Horário</h3>
                    <p className="text-gray-600 text-sm md:text-base">Seg-Sex: 09:00 às 20:00</p>
                    <p className="text-gray-600 text-sm md:text-base">Sábado: 09:00 às 18:00</p>
                  </div>
                </div>

                <Button
                  onClick={openScheduleModal}
                  className="w-full bg-[#800020] hover:bg-[#600018] text-white font-bold py-3"
                >
                  AGENDAR AGORA
                </Button>
              </div>
            </div>

            {/* Google Map */}
            <div className="h-96 md:h-full rounded-lg overflow-hidden shadow-lg">
              <MapView
                initialCenter={{ lat: -25.508612, lng: -49.2496814 }}
                initialZoom={18}
              />
            </div>
          </div>
        </div>
      </section>

      {/* Contato Section */}
      <section id="contato" className="py-20 md:py-32 bg-white">
        <div className="container">
          <div className="max-w-2xl mx-auto">
            <div className="space-y-4 mb-12 text-center">
              <p className="text-[#D4AF37] font-semibold text-sm tracking-widest">ENTRE EM CONTATO</p>
              <h2 className="text-4xl md:text-5xl font-serif font-bold text-[#800020]">
                Fale Conosco
              </h2>
            </div>

            <form className="space-y-6 bg-gray-50 p-8 rounded-lg">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Nome</label>
                <Input
                  type="text"
                  placeholder="Seu nome"
                  className="w-full border-2 border-gray-300 focus:border-[#D4AF37] rounded-lg p-3"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Email</label>
                <Input
                  type="email"
                  placeholder="seu@email.com"
                  className="w-full border-2 border-gray-300 focus:border-[#D4AF37] rounded-lg p-3"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Mensagem</label>
                <Textarea
                  placeholder="Sua mensagem"
                  className="w-full border-2 border-gray-300 focus:border-[#D4AF37] rounded-lg p-3 min-h-32"
                />
              </div>

              <Button className="w-full bg-[#800020] hover:bg-[#600018] text-white font-bold py-3 text-lg">
                ENVIAR MENSAGEM
              </Button>
            </form>
          </div>
        </div>
      </section>

      {/* Schedule Modal */}
      <Dialog open={showScheduleModal} onOpenChange={setShowScheduleModal}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl font-serif font-bold text-[#800020]">
              Agendar Atendimento
            </DialogTitle>
          </DialogHeader>

          <form onSubmit={handleScheduleSubmit} className="space-y-6">
            {/* Serviços Selecionados */}
            {selectedServices.length > 0 && (
              <div className="bg-[#D4AF37]/10 p-4 rounded-lg border-l-4 border-[#D4AF37]">
                <p className="text-sm font-semibold text-gray-700">
                  <span className="text-[#800020]">Serviços:</span> {selectedServicesText}
                </p>
                <p className="text-lg font-bold text-[#800020] mt-2">
                  Total: R$ {totalPrice.toFixed(2)}
                </p>
              </div>
            )}

            {/* Nome */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Nome *</label>
              <Input
                type="text"
                placeholder="Seu nome completo"
                value={formData.name}
                onChange={e => setFormData(prev => ({ ...prev, name: e.target.value }))}
                className="w-full border-2 border-gray-300 focus:border-[#D4AF37] rounded-lg p-3"
              />
            </div>

            {/* Email */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Email *</label>
              <Input
                type="email"
                placeholder="seu@email.com"
                value={formData.email}
                onChange={e => setFormData(prev => ({ ...prev, email: e.target.value }))}
                className="w-full border-2 border-gray-300 focus:border-[#D4AF37] rounded-lg p-3"
              />
            </div>

            {/* Telefone */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Telefone *</label>
              <Input
                type="tel"
                placeholder="(41) 99999-9999"
                value={formData.phone}
                onChange={e => setFormData(prev => ({ ...prev, phone: maskPhone(e.target.value) }))}
                className="w-full border-2 border-gray-300 focus:border-[#D4AF37] rounded-lg p-3"
              />
            </div>

            {/* Data */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Data *</label>
              <Input
                type="date"
                value={formData.date}
                onChange={e => setFormData(prev => ({ ...prev, date: e.target.value }))}
                className="w-full border-2 border-gray-300 focus:border-[#D4AF37] rounded-lg p-3"
              />
            </div>

            {/* Hora */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Hora *</label>
              <Input
                type="time"
                value={formData.time}
                onChange={e => setFormData(prev => ({ ...prev, time: e.target.value }))}
                className="w-full border-2 border-gray-300 focus:border-[#D4AF37] rounded-lg p-3"
              />
            </div>

            {/* CPF do Cliente */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Seu CPF *</label>
              <Input
                type="text"
                placeholder="000.000.000-00"
                value={formData.clientCPF}
                onChange={handleClientCPFChange}
                maxLength={14}
                className={`w-full border-2 rounded-lg p-3 ${
                  cpfError ? 'border-red-500 focus:border-red-500' : 'border-gray-300 focus:border-[#D4AF37]'
                }`}
              />
              {cpfError && <p className="text-red-500 text-sm mt-1">{cpfError}</p>}
            </div>

            {/* CPF de Indicação (Condicional) */}
            {totalPrice > 0 && (
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Quem te indicou? (Digite o CPF)</label>
                <Input
                  type="text"
                  placeholder="000.000.000-00"
                  value={formData.referralCPF}
                  onChange={handleReferralCPFChange}
                  maxLength={14}
                  className={`w-full border-2 rounded-lg p-3 ${
                    referralCpfError ? 'border-red-500 focus:border-red-500' : 'border-gray-300 focus:border-[#D4AF37]'
                  }`}
                />
                {referralCpfError && <p className="text-red-500 text-sm mt-1">{referralCpfError}</p>}
                <p className="text-xs italic text-gray-600 mt-2">
                  Complete 10 indicações com seu CPF e ganhe 10% de desconto real no próximo atendimento.
                </p>
              </div>
            )}

            {/* Mensagem */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Mensagem (Opcional)</label>
              <Textarea
                placeholder="Deixe uma mensagem ou observação"
                value={formData.message}
                onChange={e => setFormData(prev => ({ ...prev, message: e.target.value }))}
                className="w-full border-2 border-gray-300 focus:border-[#D4AF37] rounded-lg p-3 min-h-24"
              />
            </div>

            {/* Mensagem de Sucesso */}
            {successMessage && (
              <div className="bg-green-50 border-l-4 border-green-500 p-4 rounded">
                <p className="text-green-700 font-semibold">{successMessage}</p>
              </div>
            )}

            {/* Botões */}
            <div className="flex gap-4 pt-4">
              <Button
                type="submit"
                className="flex-1 bg-[#800020] hover:bg-[#600018] text-white font-bold py-3 text-lg"
                disabled={!!cpfError || (totalPrice > 0 && !!referralCpfError)}
              >
                CONFIRMAR AGENDAMENTO
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowScheduleModal(false)}
                className="flex-1 border-2 border-[#800020] text-[#800020] hover:bg-[#800020] hover:text-white font-bold py-3"
              >
                CANCELAR
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Instagram Floating Button */}
      <a
        href="https://instagram.com/vonbarbarov"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-24 right-6 z-40 bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 hover:shadow-2xl text-white rounded-full p-4 shadow-lg transition-all duration-300 hover:scale-110 flex items-center justify-center"
        title="Ver portfólio no Instagram"
      >
        <Instagram className="w-6 h-6" />
      </a>

      {/* WhatsApp Floating Button */}
      <a
        href="https://wa.me/5541992057764?text=Olá%20Von%20Barbarov!%20Gostaria%20de%20agendar%20um%20horário."
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-40 bg-green-500 hover:bg-green-600 text-white rounded-full p-4 shadow-lg transition-all duration-300 hover:scale-110 flex items-center justify-center"
        title="Enviar mensagem no WhatsApp"
      >
        <MessageCircle className="w-6 h-6" />
      </a>

      {/* Footer */}
      <footer className="bg-[#800020] text-white py-12">
        <div className="container">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-6 h-6 bg-[#D4AF37] rounded-full flex items-center justify-center">
                  <span className="text-[#800020] font-bold text-xs">✂</span>
                </div>
                <h3 className="text-lg md:text-xl font-bold">Von Barbarov</h3>
              </div>
              <p className="text-gray-300 text-sm md:text-base">Barbearia Premium desde 2015</p>
            </div>

            <div>
              <h4 className="font-bold mb-4 text-[#D4AF37]">Links</h4>
              <ul className="space-y-2 text-gray-300 text-sm">
                <li><a href="#historia" className="hover:text-[#D4AF37] transition-colors">História</a></li>
                <li><a href="#servicos" className="hover:text-[#D4AF37] transition-colors">Serviços</a></li>
                <li><a href="#depoimentos" className="hover:text-[#D4AF37] transition-colors">Depoimentos</a></li>
                <li><a href="#localizacao" className="hover:text-[#D4AF37] transition-colors">Localização</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold mb-4 text-[#D4AF37]">Contato</h4>
              <ul className="space-y-2 text-gray-300 text-sm">
                <li><a href="tel:+554132057764" className="hover:text-[#D4AF37] transition-colors">(41) 3205-7764</a></li>
                <li><a href="mailto:contato@vonbarbarov.com.br" className="hover:text-[#D4AF37] transition-colors">contato@vonbarbarov.com.br</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold mb-4 text-[#D4AF37]">Horário</h4>
              <ul className="space-y-2 text-gray-300 text-sm">
                <li>Seg-Sex: 09:00 às 20:00</li>
                <li>Sábado: 09:00 às 18:00</li>
                <li>Domingo: Fechado</li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-700 pt-8">
            <p className="text-center text-gray-400 text-sm">
              © 2025 Von Barbarov. Todos os direitos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
