import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { CheckCircle, XCircle, Clock, AlertCircle } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";

export default function AdminDashboard() {
  const { user, loading: authLoading } = useAuth();
  const [location, setLocation] = useLocation();
  const [selectedAppointment, setSelectedAppointment] = useState<any>(null);
  const [showDialog, setShowDialog] = useState(false);

  // Redireciona se não for admin
  if (!authLoading && (!user || user.role !== "admin")) {
    setLocation("/");
    return null;
  }

  const { data: appointments = [], isLoading, refetch } = trpc.appointments.list.useQuery(undefined, {
    enabled: !!user && user.role === "admin",
  });

  const updateStatusMutation = trpc.appointments.updateStatus.useMutation({
    onSuccess: () => {
      refetch();
      setShowDialog(false);
    },
  });

  const handleStatusChange = (appointmentId: number, newStatus: string) => {
    updateStatusMutation.mutate({
      id: appointmentId,
      status: newStatus as any,
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pendente":
        return "bg-yellow-100 text-yellow-800";
      case "confirmado":
        return "bg-blue-100 text-blue-800";
      case "concluido":
        return "bg-green-100 text-green-800";
      case "cancelado":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pendente":
        return <Clock className="w-4 h-4" />;
      case "confirmado":
        return <AlertCircle className="w-4 h-4" />;
      case "concluido":
        return <CheckCircle className="w-4 h-4" />;
      case "cancelado":
        return <XCircle className="w-4 h-4" />;
      default:
        return null;
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F5F5F5]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#800020] mx-auto mb-4"></div>
          <p className="text-[#1A1A1A]">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F5F5]">
      {/* Header */}
      <div className="bg-white border-b border-[#D4AF37]/20 sticky top-0 z-40">
        <div className="container py-4 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-[#800020]">Painel de Administração</h1>
            <p className="text-[#666666] text-sm">Barbearia Von Barbarov</p>
          </div>
          <Button
            onClick={() => setLocation("/")}
            variant="outline"
            className="border-[#800020] text-[#800020] hover:bg-[#800020] hover:text-white"
          >
            Voltar ao Site
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="container py-8">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="p-6 border-l-4 border-l-yellow-500">
            <p className="text-[#666666] text-sm font-medium">Pendentes</p>
            <p className="text-3xl font-bold text-[#800020] mt-2">
              {appointments.filter((a) => a.status === "pendente").length}
            </p>
          </Card>
          <Card className="p-6 border-l-4 border-l-blue-500">
            <p className="text-[#666666] text-sm font-medium">Confirmados</p>
            <p className="text-3xl font-bold text-[#800020] mt-2">
              {appointments.filter((a) => a.status === "confirmado").length}
            </p>
          </Card>
          <Card className="p-6 border-l-4 border-l-green-500">
            <p className="text-[#666666] text-sm font-medium">Concluídos</p>
            <p className="text-3xl font-bold text-[#800020] mt-2">
              {appointments.filter((a) => a.status === "concluido").length}
            </p>
          </Card>
          <Card className="p-6 border-l-4 border-l-red-500">
            <p className="text-[#666666] text-sm font-medium">Cancelados</p>
            <p className="text-3xl font-bold text-[#800020] mt-2">
              {appointments.filter((a) => a.status === "cancelado").length}
            </p>
          </Card>
        </div>

        {/* Appointments List */}
        <Card className="border border-[#D4AF37]/20">
          <div className="p-6 border-b border-[#D4AF37]/20">
            <h2 className="text-2xl font-bold text-[#800020]">Agendamentos</h2>
            <p className="text-[#666666] text-sm mt-1">Total: {appointments.length}</p>
          </div>

          {isLoading ? (
            <div className="p-8 text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#800020] mx-auto mb-4"></div>
              <p className="text-[#666666]">Carregando agendamentos...</p>
            </div>
          ) : appointments.length === 0 ? (
            <div className="p-8 text-center">
              <p className="text-[#666666]">Nenhum agendamento realizado ainda.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-[#F5F5F5] border-b border-[#D4AF37]/20">
                  <tr>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-[#1A1A1A]">Cliente</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-[#1A1A1A]">Telefone</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-[#1A1A1A]">Serviço</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-[#1A1A1A]">Data/Hora</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-[#1A1A1A]">Status</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-[#1A1A1A]">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {appointments.map((appointment) => (
                    <tr key={appointment.id} className="border-b border-[#E0E0E0] hover:bg-[#F5F5F5]">
                      <td className="px-6 py-4">
                        <div>
                          <p className="font-medium text-[#1A1A1A]">{appointment.name}</p>
                          <p className="text-sm text-[#666666]">{appointment.email}</p>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-[#1A1A1A]">{appointment.phone}</td>
                      <td className="px-6 py-4 text-[#1A1A1A] text-sm">{appointment.services}</td>
                      <td className="px-6 py-4 text-[#1A1A1A]">
                        <div className="text-sm">
                          <p className="font-medium">{appointment.appointmentDate}</p>
                          <p className="text-[#666666]">{appointment.appointmentTime}</p>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <Badge className={`${getStatusColor(appointment.status)} flex items-center gap-2 w-fit`}>
                          {getStatusIcon(appointment.status)}
                          {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                        </Badge>
                      </td>
                      <td className="px-6 py-4">
                        <Button
                          size="sm"
                          onClick={() => {
            setSelectedAppointment(appointment);
            setShowDialog(true);
          }}
                          className="bg-[#800020] hover:bg-[#600018] text-white"
                        >
                          Gerenciar
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      </div>

      {/* Dialog de Gerenciamento */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-[#800020]">Gerenciar Agendamento</DialogTitle>
          </DialogHeader>

          {selectedAppointment && (
            <div className="space-y-4">
              <div className="bg-[#F5F5F5] p-4 rounded-lg">
                <p className="text-sm text-[#666666]">Cliente</p>
                <p className="font-medium text-[#1A1A1A]">{selectedAppointment.name}</p>

                <p className="text-sm text-[#666666] mt-3">Serviço</p>
                <p className="font-medium text-[#1A1A1A]">{selectedAppointment.services}</p>

                <p className="text-sm text-[#666666] mt-3">Data/Hora</p>
                <p className="font-medium text-[#1A1A1A]">
                  {selectedAppointment.appointmentDate} às {selectedAppointment.appointmentTime}
                </p>

                <p className="text-sm text-[#666666] mt-3">Status Atual</p>
                <Badge className={`${getStatusColor(selectedAppointment.status)} mt-1`}>
                  {selectedAppointment.status.charAt(0).toUpperCase() + selectedAppointment.status.slice(1)}
                </Badge>
              </div>

              <div className="space-y-2">
                <p className="text-sm font-medium text-[#1A1A1A]">Alterar Status</p>
                <div className="grid grid-cols-2 gap-2">
                  <Button
                    size="sm"
                    variant={selectedAppointment.status === "confirmado" ? "default" : "outline"}
                    onClick={() => handleStatusChange(selectedAppointment.id, "confirmado")}
                    className={selectedAppointment.status === "confirmado" ? "bg-[#800020]" : ""}
                    disabled={updateStatusMutation.isPending}
                  >
                    Confirmar
                  </Button>
                  <Button
                    size="sm"
                    variant={selectedAppointment.status === "concluido" ? "default" : "outline"}
                    onClick={() => handleStatusChange(selectedAppointment.id, "concluido")}
                    className={selectedAppointment.status === "concluido" ? "bg-green-600" : ""}
                    disabled={updateStatusMutation.isPending}
                  >
                    Concluir
                  </Button>
                  <Button
                    size="sm"
                    variant={selectedAppointment.status === "cancelado" ? "default" : "outline"}
                    onClick={() => handleStatusChange(selectedAppointment.id, "cancelado")}
                    className={selectedAppointment.status === "cancelado" ? "bg-red-600" : ""}
                    disabled={updateStatusMutation.isPending}
                  >
                    Cancelar
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
